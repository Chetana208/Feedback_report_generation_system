export const StatusEnum = {
  POOR: { value: "0", label: "Poor" },
  GOOD: { value: "1", label: "Good" },
  SATISFACTORY: { value: "2", label: "Satisfactory" },
  EXCELLENT: { value: "3", label: "Excellent" },
};
