export const roleOptions = [
  { value: "student", label: "Student" },
  { value: "faculty", label: "Faculty" },
];
