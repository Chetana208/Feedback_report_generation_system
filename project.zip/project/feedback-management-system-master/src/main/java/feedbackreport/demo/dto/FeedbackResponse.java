package feedbackreport.demo.dto;

import lombok.Data;

@Data
public class FeedbackResponse {
    private int question_id;
    private int status;

    // Constructors, getters, setters
}

