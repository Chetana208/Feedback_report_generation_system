package feedbackreport.demo.repository;

public interface CourseDetails {
    int getCourse_id();

    String getCourse_name();
}
