package feedbackreport.demo.dto;

import lombok.Data;

@Data
public class AverageStatusResponse {
    private Double averageStatus;
}

