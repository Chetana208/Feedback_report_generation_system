# feedback-management-system
**Description**



**ER Diagram**

![STUDENT_FEEDBACK_SYSTEM_ER_DAIGRAM](https://github.com/Dhruti313/feedback-management-system/assets/124250238/1bb5dcba-63b9-41f1-946e-6260eb81d0b9)
